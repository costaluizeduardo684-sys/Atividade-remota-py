############################################################
# Descrição: Verifica se um valor é positivo ou negativo.
# Parâmetros de entrada: Um número informado pelo usuário.
# Valores de saída: A classificação do número como positivo, negativo ou zero.
# Autor: [Seu Nome Completo]
############################################################

valor = float(input("Digite um valor: "))

if valor > 0:
    print("O valor é positivo.")
elif valor < 0:
    print("O valor é negativo.")
else:
    print("O valor é zero.")
