############################################################
# Descrição: Apresenta os quadrados dos números inteiros de 15 até 200.
# Parâmetros de entrada: Não há entrada do usuário.
# Valores de saída: O quadrado de cada número inteiro de 15 a 200.
# Autor: [Seu Nome Completo]
############################################################

for numero in range(15, 201):
    quadrado = numero ** 2
    print(numero, "ao quadrado =", quadrado)
