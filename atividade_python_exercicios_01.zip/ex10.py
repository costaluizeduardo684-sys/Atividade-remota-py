############################################################
# Descrição: Apresenta todos os números ímpares de 0 até 20.
# Parâmetros de entrada: Não há entrada do usuário.
# Valores de saída: Os números ímpares existentes entre 0 e 20.
# Autor: [Seu Nome Completo]
############################################################

for numero in range(0, 21):
    if numero % 2 != 0:
        print(numero)
