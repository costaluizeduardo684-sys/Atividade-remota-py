# Atividade Remota 01 — Python

## Organização
Cada exercício foi desenvolvido em um arquivo Python separado:
- `ex01.py` até `ex10.py`.

Todos os arquivos possuem o cabeçalho obrigatório com descrição, parâmetros de entrada, valores de saída e autor.

## Como executar
Tenha o Python 3 instalado. No terminal, entre na pasta do projeto e execute, por exemplo:

```bash
python ex01.py
```

Troque `ex01.py` pelo arquivo do exercício que deseja executar.

## Antes de entregar
1. Abra cada arquivo e substitua `[Seu Nome Completo]` pelo seu nome.
2. Execute os exercícios para conferir os resultados.
3. Crie um repositório **público** no GitHub.
4. Envie os arquivos para o repositório, seguindo os commits individuais descritos nas instruções da atividade.
5. Copie o link do repositório e cole na atividade do MS Teams.

## Commits individuais
Faça um commit para cada exercício, depois de criar/concluir o respectivo arquivo:

```bash
git add ex01.py
git commit -m "feat: conclui o exercicio 01"
git push
```

Repita o processo, trocando o número do arquivo e da mensagem, até o `ex10.py`.

## Exemplo para iniciar o repositório

```bash
git init
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
```

Depois dos commits individuais, envie tudo com:

```bash
git push -u origin main
```

Se o repositório já tiver sido criado e conectado, não é necessário repetir `git init` nem `git remote add origin`.
