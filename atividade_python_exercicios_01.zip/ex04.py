############################################################
# Descrição: Mostra uma saudação de acordo com o turno de estudo.
# Parâmetros de entrada: Uma letra: M, V ou N.
# Valores de saída: Bom Dia!, Boa Tarde!, Boa Noite! ou Valor Inválido!
# Autor: [Seu Nome Completo]
############################################################

turno = input("Digite M para Matutino, V para Vespertino ou N para Noturno: ").strip().upper()

if turno == "M":
    print("Bom Dia!")
elif turno == "V":
    print("Boa Tarde!")
elif turno == "N":
    print("Boa Noite!")
else:
    print("Valor Inválido!")
