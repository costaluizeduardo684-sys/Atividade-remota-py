############################################################
# Descrição: Calcula a soma dos cem primeiros números naturais, de 1 até 100.
# Parâmetros de entrada: Não há entrada do usuário.
# Valores de saída: A soma dos números de 1 a 100.
# Autor: [Seu Nome Completo]
############################################################

soma = 0

for numero in range(1, 101):
    soma += numero

print("A soma dos números de 1 a 100 é:", soma)
