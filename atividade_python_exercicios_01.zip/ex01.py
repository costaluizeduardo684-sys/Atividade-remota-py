############################################################
# Descrição: Compara dois números e mostra o maior deles.
# Parâmetros de entrada: Dois números informados pelo usuário.
# Valores de saída: O maior número ou uma mensagem informando que são iguais.
# Autor: [Seu Nome Completo]
############################################################

numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

if numero1 > numero2:
    print("O maior número é:", numero1)
elif numero2 > numero1:
    print("O maior número é:", numero2)
else:
    print("Os dois números são iguais.")
