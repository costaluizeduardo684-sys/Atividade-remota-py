############################################################
# Descrição: Calcula a soma dos números pares de 1 até 500.
# Parâmetros de entrada: Não há entrada do usuário.
# Valores de saída: A soma de todos os números pares entre 1 e 500.
# Autor: [Seu Nome Completo]
############################################################

soma = 0

for numero in range(1, 501):
    if numero % 2 == 0:
        soma += numero

print("A soma dos números pares de 1 a 500 é:", soma)
