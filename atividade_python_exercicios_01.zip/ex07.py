############################################################
# Descrição: Apresenta a tabuada de um número informado pelo usuário.
# Parâmetros de entrada: Um número informado pelo usuário.
# Valores de saída: A tabuada do número, de 1 até 10.
# Autor: [Seu Nome Completo]
############################################################

numero = int(input("Digite um número para ver sua tabuada: "))

for multiplicador in range(1, 11):
    resultado = numero * multiplicador
    print(f"{numero} x {multiplicador} = {resultado}")
